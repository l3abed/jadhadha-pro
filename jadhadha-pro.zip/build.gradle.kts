plugins {
  id("com.android.application") version "9.1.1" apply false
  id("org.jetbrains.kotlin.plugin.compose") version "2.2.10" apply false
  id("com.chaquo.python") version "17.2.0" apply false
}
