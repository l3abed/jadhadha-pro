plugins {
  id("com.android.application")
  id("org.jetbrains.kotlin.plugin.compose")
  id("com.chaquo.python")
}

android {
  namespace = "com.l3abed.jadhadha.pro"
  compileSdk = 36

  defaultConfig {
    applicationId = "com.l3abed.jadhadha.pro"
    minSdk = 24
    targetSdk = 36
    versionCode = 21
    versionName = "1.0.0"

    ndk {
      // Python 3.12+ يدعم 64 بت فقط
      abiFilters += listOf("arm64-v8a", "x86_64")
    }
  }

  signingConfigs {
    // مفتاح ثابت داخل المشروع ليبقى توقيع كل الإصدارات واحداً (فيعمل التحديث فوق النسخة المثبّتة)
    create("release") {
      storeFile = file("jadhadha-release.jks")
      storePassword = "jadhadha123"
      keyAlias = "jadhadha"
      keyPassword = "jadhadha123"
    }
  }

  buildTypes {
    release {
      isMinifyEnabled = false
      signingConfig = signingConfigs.getByName("release")
    }
    debug {
      signingConfig = signingConfigs.getByName("release")
    }
  }

  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
  }

  buildFeatures {
    compose = true
  }
}

chaquopy {
  defaultConfig {
    version = "3.13"
    pip {
      install("python-docx")
    }
  }
}

dependencies {
  implementation(platform("androidx.compose:compose-bom:2024.09.00"))
  implementation("androidx.activity:activity-compose:1.10.1")
  implementation("androidx.compose.material3:material3")
  implementation("androidx.compose.ui:ui")
  implementation("androidx.core:core-ktx:1.15.0")
  implementation("androidx.documentfile:documentfile:1.0.1")
  implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
}
