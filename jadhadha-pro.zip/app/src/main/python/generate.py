# -*- coding: utf-8 -*-
"""
generate.py — توليد جذاذة بالذكاء الاصطناعي من (الدرس، المقرر، الفئة، النشاط).

الذكاء الاصطناعي يُنتج بنية JSON فقط. تُتحقَّق البنية، ثم تُكتب في ملف مصدر docx
بالشكل الذي تقرؤه أدوات التفريغ، فتمرّ الجذاذة على القوالب نفسها كأي مصدر.
لا يُدرج نص الانطلاق في الجذاذة المولَّدة.
"""
import json
import re
from pathlib import Path

from docx import Document
from docx.shared import Pt

STAGES = {
    "reading": ["تقويم تشخيصي", "تأطير النص", "فهم النص", "القراءة التحليلية", "التركيب", "الاستثمار"],
    "language": ["تقويم تشخيصي", "ملاحظة الأمثلة ووصفها وتحليلها", "الاستنتاج", "التطبيق والاستثمار"],
    "expression": None,       # يحدده النشاط
}
EXPRESSION_STAGES = {
    "الاكتساب": ["تقويم تشخيصي", "اكتساب المهارة", "الاستنتاج"],
    "التطبيق": ["تقويم تشخيصي", "فهم المطلوب", "الإنجاز"],
    "الإنتاج": ["تقويم تشخيصي", "فهم المطلوب", "الإنجاز"],
    "التصحيح": ["تقويم تشخيصي", "التصحيح"],
}
COMP_LABEL = {"reading": "القراءة", "language": "الدرس اللغوي", "expression": "التعبير والإنشاء"}
_MAX = 400


class GenerationError(Exception):
    pass


def stages_for(component: str, activity: str = "") -> list:
    if component == "expression":
        if activity not in EXPRESSION_STAGES:
            raise GenerationError("اختر نشاط التعبير: الاكتساب أو التطبيق أو الإنتاج أو التصحيح.")
        return EXPRESSION_STAGES[activity]
    if component not in STAGES:
        raise GenerationError("مكوّن غير معروف.")
    return STAGES[component]


def build_prompt(component: str, lesson: str, subject: str, level: str, stages: list) -> str:
    schema = {
        "header": {"unit": "", "domain": "", "topic": "", "duration": "",
                   "competencies": {"تواصلية": "", "منهجية": "", "ثقافية": ""}},
        "stages": [{"name": s, "capabilities": ["..."], "teacher": ["..."],
                    "content": ["..."], "evaluation": ["..."]} for s in stages],
    }
    return (
        "أنت مفتش تربوي خبير بالجذاذات المغربية لمادة اللغة العربية في التعليم الإعدادي.\n"
        f"اكتب جذاذة «{COMP_LABEL[component]}» للدرس: «{lesson}»، المقرر: «{subject}»، الفئة المستهدفة: «{level}».\n"
        "القواعد الصارمة:\n"
        "1. أعد JSON فقط بالبنية المطلوبة، دون أي نص خارجه.\n"
        f"2. المراحل بهذه الأسماء وبهذا الترتيب بالضبط: {json.dumps(stages, ensure_ascii=False)}.\n"
        "3. لا تُدرج أي نص انطلاق (قصيدة أو نص أدبي أو مقطع)؛ اكتب الأسئلة والأنشطة فقط، ويُلصق الأستاذ النص لاحقاً.\n"
        "4. لا تذكر أرقام صفحات أو مراجع كتب أو أسماء مؤلفين مختلقة.\n"
        "5. الأنشطة جمل مباشرة (أسئلة أو مطالب)، دون عبارات مثل «يطرح الأستاذ» أو «يتأمل المتعلم».\n"
        "6. كل ما تكتبه مقترح يراجعه الأستاذ؛ لا تدّعِ يقيناً علمياً.\n"
        "الصيغة: " + json.dumps(schema, ensure_ascii=False) + "\n"
    )


def _arabic_ratio(s: str) -> float:
    letters = re.findall(r"\S", s)
    if not letters:
        return 0.0
    ar = re.findall(r"[\u0600-\u06FF]", s)
    return len(ar) / len(letters)


def validate(data: dict, component: str, stages: list) -> dict:
    if not isinstance(data, dict) or "stages" not in data or "header" not in data:
        raise GenerationError("استجابة الذكاء الاصطناعي لا تطابق البنية المطلوبة.")
    got = [s.get("name") for s in data["stages"] if isinstance(s, dict)]
    if got != stages:
        raise GenerationError("المراحل المُرجعة لا تطابق المراحل المطلوبة، لن تُستعمل الجذاذة.")
    for s in data["stages"]:
        for key in ("capabilities", "teacher", "content", "evaluation"):
            items = s.get(key, [])
            if not isinstance(items, list):
                raise GenerationError(f"حقل «{key}» ليس قائمة.")
            s[key] = [str(x).strip()[:_MAX] for x in items if str(x).strip()]
        if not s["teacher"] or not s["evaluation"]:
            raise GenerationError(f"مرحلة «{s['name']}» بلا أنشطة أو تقويم.")
        text = " ".join(s["teacher"] + s["content"])
        if text and _arabic_ratio(text) < 0.6:
            raise GenerationError("النص المُرجع ليس عربياً بما يكفي.")
    h = data["header"]
    for k in ("unit", "domain", "topic", "duration"):
        h[k] = str(h.get(k, "")).strip()[:_MAX]
    return data


def write_source_docx(data: dict, component: str, lesson: str, subject: str, level: str, path: Path) -> Path:
    """يكتب الجذاذة المُولَّدة في ملف مصدر بالترويسة وجدول المراحل كما تقرؤه أدوات التفريغ."""
    doc = Document()
    h = data["header"]
    lines = [f"الفئة المستهدفة: {level}", f"الوحدة: {h.get('unit', '')}",
             f"المجال: {h.get('domain', '')}", f"المكون: {COMP_LABEL[component]}",
             f"الموضوع: {lesson}", f"المادة: {subject}", f"مدة الإنجاز: {h.get('duration', '')}"]
    comps = h.get("competencies", {}) or {}
    for k in ("تواصلية", "منهجية", "ثقافية"):
        if comps.get(k):
            lines.append(f"كفاية {k}: {comps[k]}")
    for ln in lines:
        doc.add_paragraph(ln)
    heads = ["المراحل", "القدرات والمهارات", "الأنشطة التعليمية", "المحتوى", "التقويم والدعم"]
    table = doc.add_table(rows=1, cols=len(heads))
    table.style = "Table Grid"
    for i, t in enumerate(heads):
        table.rows[0].cells[i].text = t
    for s in data["stages"]:
        cells = table.add_row().cells
        cells[0].text = s["name"]
        cells[1].text = "\n".join("- " + x for x in s["capabilities"])
        cells[2].text = "\n".join("- " + x for x in s["teacher"])
        cells[3].text = "\n".join("- " + x for x in s["content"])
        cells[4].text = "\n".join("- " + x for x in s["evaluation"])
    for row in table.rows:
        for c in row.cells:
            for p in c.paragraphs:
                for r in p.runs:
                    r.font.size = Pt(10)
    doc.save(str(path))
    return path


def generate(component: str, lesson: str, subject: str, level: str, activity: str,
             api_key: str, out_dir: Path, ai_model: str = "") -> Path:
    """يولّد جذاذة ويعيد مسار ملف المصدر المُولَّد (يُمرَّر بعدها إلى القالب)."""
    import language as L
    if not api_key:
        raise GenerationError("التوليد يحتاج مفتاح Gemini (فعّل الذكاء الاصطناعي وأدخل المفتاح).")
    if not lesson.strip():
        raise GenerationError("أدخل اسم الدرس.")
    stages = stages_for(component, activity)
    cfg = L.Settings()
    cfg.api_key = api_key
    if ai_model:
        cfg.ai_model = ai_model
    data = L.call_gemini(build_prompt(component, lesson.strip(), subject.strip(), level.strip(), stages), cfg)
    data = validate(data, component, stages)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    name = re.sub(r'[<>:"/\\|?*\r\n\t]+', "", f"مقترح_{lesson.strip()}.docx")
    return write_source_docx(data, component, lesson.strip(), subject.strip(), level.strip(), out_dir / name)
