# -*- coding: utf-8 -*-
"""
bridge.py — واجهة موحّدة لسكريبتات الجذاذات الثلاثة (قراءة / لغة / تعبير).

يستدعيها التطبيق (Chaquopy) هكذا:
    run("reading" | "language" | "expression", model_path, source_path, out_dir, api_key="", out_name="")
وتعيد نص JSON:  {"ok": bool, "path": "...", "log": "...", "error": "..."}

لا مفتاح داخل الكود: إن مُرِّر api_key فُعّل التنقيح بالذكاء الاصطناعي، وإلا عمل السكريبت دون إنترنت.
"""
import contextlib
import importlib
import io
import json
import os
import re
import sys
import traceback
from pathlib import Path

_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

COMPONENTS = ("reading", "language", "expression")
_PATH_RE = re.compile(r"(?:الملف|تم الحفظ بنجاح في)\s*:\s*(.+?\.docx)\s*$", re.M)
_BAD_NAME = re.compile(r'[<>:"/\\|?*\r\n\t]+')


def _newest_docx(root):
    files = [p for p in Path(root).rglob("*.docx")]
    return str(max(files, key=lambda p: p.stat().st_mtime)) if files else ""


@contextlib.contextmanager
def _env_key(api_key):
    old = os.environ.get("GEMINI_API_KEY")
    if api_key:
        os.environ["GEMINI_API_KEY"] = api_key
    else:
        os.environ.pop("GEMINI_API_KEY", None)
    try:
        yield
    finally:
        if old is None:
            os.environ.pop("GEMINI_API_KEY", None)
        else:
            os.environ["GEMINI_API_KEY"] = old


def _run_reading(model, source, out_dir, api_key, out_name=""):
    mod = importlib.import_module("reading")
    mod.USED_OUTPUTS.clear()
    ai = mod.AICfg(mod.DEFAULT_AI_MODEL, api_key) if api_key else None
    name = _BAD_NAME.sub("", out_name or "").strip(" .")
    if not name:
        name = "جذاذة_" + Path(source).stem + ".docx"
    elif not name.lower().endswith(".docx"):
        name += ".docx"
    mod.build(str(model), str(source), name, ai, Path(out_dir), True)


def _run_cli(component, model, source, out_dir, api_key):
    mod = importlib.import_module(component)
    argv = [str(model), str(source), "-o", str(out_dir)]
    if component == "language":
        argv += ["--api-key", api_key] if api_key else ["--no-ai"]
    code = mod.main(argv)
    if code not in (0, None):
        raise RuntimeError("انتهى السكريبت برمز خطأ %s" % code)


def run(component, model, source, out_dir, api_key="", out_name=""):
    res = {"ok": False, "path": "", "log": "", "error": ""}
    buf = io.StringIO()
    try:
        if component not in COMPONENTS:
            raise ValueError("مكوّن غير معروف: %s" % component)
        Path(out_dir).mkdir(parents=True, exist_ok=True)
        with _env_key(api_key), contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
            if component == "reading":
                _run_reading(model, source, out_dir, api_key, out_name)
            else:
                _run_cli(component, model, source, out_dir, api_key)
        log = buf.getvalue()
        m = _PATH_RE.findall(log)
        res["path"] = m[-1].strip() if m else _newest_docx(out_dir)
        res["ok"] = bool(res["path"]) and Path(res["path"]).exists()
        if not res["ok"]:
            res["error"] = "لم يُنتَج ملف ناتج."
    except SystemExit as e:                      # ShapeError في سكريبت القراءة يرث SystemExit
        res["error"] = str(e) or "تخطيط المصدر غير مدعوم."
    except Exception as e:
        res["error"] = "%s: %s" % (type(e).__name__, e)
        buf.write(traceback.format_exc())
    res["log"] = buf.getvalue()
    return json.dumps(res, ensure_ascii=False)


if __name__ == "__main__":
    if len(sys.argv) < 5:
        print("الاستعمال: python bridge.py <reading|language|expression> <model.docx> <source.docx> <out_dir> [api_key] [out_name]")
        sys.exit(2)
    print(run(*sys.argv[1:5],
              api_key=(sys.argv[5] if len(sys.argv) > 5 else ""),
              out_name=(sys.argv[6] if len(sys.argv) > 6 else "")))
