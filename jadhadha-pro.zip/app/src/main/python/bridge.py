# -*- coding: utf-8 -*-
"""
bridge.py — واجهة موحّدة لسكريبتات الجذاذات الثلاثة (قراءة / لغة / تعبير).

يستدعيها التطبيق (Chaquopy) هكذا:
    run("reading" | "language" | "expression", model_path, source_path, out_dir, api_key="", out_name="")
وتعيد نص JSON:  {"ok": bool, "path": "...", "log": "...", "error": "...", "target": {"component": "..", "unit": ".."}}

لا مفتاح داخل الكود: إن مُرِّر api_key فُعّل التنقيح بالذكاء الاصطناعي، وإلا عمل السكريبت دون إنترنت.
"""
import contextlib
import importlib
import io
import json
import os
import re
import sys
import traceback
from pathlib import Path

_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

COMPONENTS = ("reading", "language", "expression")
_PATH_RE = re.compile(r"(?:الملف|تم الحفظ بنجاح في)\s*:\s*(.+?\.docx)\s*$", re.M)


def _newest_docx(root):
    files = [p for p in Path(root).rglob("*.docx")]
    return str(max(files, key=lambda p: p.stat().st_mtime)) if files else ""


@contextlib.contextmanager
def _env_key(api_key):
    old = os.environ.get("GEMINI_API_KEY")
    if api_key:
        os.environ["GEMINI_API_KEY"] = api_key
    else:
        os.environ.pop("GEMINI_API_KEY", None)
    try:
        yield
    finally:
        if old is None:
            os.environ.pop("GEMINI_API_KEY", None)
        else:
            os.environ["GEMINI_API_KEY"] = old


_BAD_NAME = re.compile(r'[<>:"/\\|?*\r\n\t]+')


def _run_reading(model, source, out_dir, api_key, out_name=""):
    mod = importlib.import_module("reading")
    mod.USED_OUTPUTS.clear()
    ai = mod.AICfg(mod.DEFAULT_AI_MODEL, api_key) if api_key else None
    out_name = _BAD_NAME.sub("", out_name or "").strip(" .")
    if not out_name:
        out_name = "جذاذة_" + Path(source).stem + ".docx"
    elif not out_name.lower().endswith(".docx"):
        out_name += ".docx"
    mod.build(str(model), str(source), out_name, ai, Path(out_dir), True)


def _run_cli(component, model, source, out_dir, api_key):
    mod = importlib.import_module(component)
    argv = [str(model), str(source), "-o", str(out_dir)]
    if component == "language":
        argv += ["--api-key", api_key] if api_key else ["--no-ai"]
    code = mod.main(argv)
    if code not in (0, None):
        raise RuntimeError("انتهى السكريبت برمز خطأ %s" % code)


# ───────── التعرّف على المكوّن والوحدة من ترويسة الجذاذة (لاختيار مجلد التخزين) ─────────
COMPONENT_FOLDERS = {"reading": "القراءة", "language": "الدرس اللغوي", "expression": "التعبير والإنشاء"}
_UNITS = ("الأولى", "الثانية", "الثالثة", "الرابعة", "الخامسة", "السادسة")


def _n(s):
    s = re.sub("[\u064B-\u0652\u0640]", "", s or "")
    s = re.sub("[أإآٱ]", "ا", s).replace("ى", "ي").replace("ة", "ه")
    return re.sub(r"\s+", " ", re.sub(r"[^\w\s]", " ", s)).strip()


def _header_value(table, label):
    """قيمة الخانة الواقعة قبل عنوان معيّن (الترويسة: القيمة | : | العنوان)."""
    for row in table.rows:
        seen, cells = set(), []
        for c in row.cells:
            if id(c._tc) in seen:
                continue
            seen.add(id(c._tc))
            cells.append(re.sub(r"\s+", " ", c.text).strip())
        for i, t in enumerate(cells):
            if _n(t) != label:
                continue
            j = i - 1
            while j >= 0 and (cells[j] in (":", "：", "؛") or not cells[j]):
                j -= 1
            if j >= 0:
                return cells[j]
    return ""


def detect_target(docx_path, fallback_component=""):
    """يعيد {"component": مجلد المكوّن, "unit": مجلد الوحدة} اعتماداً على ترويسة الملف."""
    from docx import Document
    comp, unit, src = "", "", ""
    try:
        doc = Document(str(docx_path))
        t = doc.tables[0]
        v_comp, v_unit = _header_value(t, "المكون"), _header_value(t, "الوحده")
        n = _n(v_comp)
        if "قراءه" in n:
            comp = COMPONENT_FOLDERS["reading"]
        elif "تعبير" in n or "انشاء" in n:
            comp = COMPONENT_FOLDERS["expression"]
        elif "لغ" in n or "قواعد" in n or "صرف" in n or "نحو" in n:
            comp = COMPONENT_FOLDERS["language"]
        nu = _n(v_unit)
        for i, w in enumerate(_UNITS, 1):
            if _n(w) in nu or re.search(r"(?<!\d)%d(?!\d)" % i, nu):
                unit = "الوحدة " + w
                break
        src = "الترويسة"
    except Exception:
        pass
    if not comp:
        comp, src = COMPONENT_FOLDERS.get(fallback_component, ""), "التبويب"
    return {"component": comp, "unit": unit, "from": src}


def run(component, model, source, out_dir, api_key="", out_name=""):
    res = {"ok": False, "path": "", "log": "", "error": "", "target": {}}
    buf = io.StringIO()
    try:
        if component not in COMPONENTS:
            raise ValueError("مكوّن غير معروف: %s" % component)
        Path(out_dir).mkdir(parents=True, exist_ok=True)
        with _env_key(api_key), contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
            if component == "reading":
                _run_reading(model, source, out_dir, api_key, out_name)
            else:
                _run_cli(component, model, source, out_dir, api_key)
        log = buf.getvalue()
        m = _PATH_RE.findall(log)
        res["path"] = m[-1].strip() if m else _newest_docx(out_dir)
        res["ok"] = bool(res["path"]) and Path(res["path"]).exists()
        if not res["ok"]:
            res["error"] = "لم يُنتَج ملف ناتج."
        else:
            res["target"] = detect_target(res["path"], component)
    except SystemExit as e:                      # ShapeError في سكريبت القراءة يرث SystemExit
        res["error"] = str(e) or "تخطيط المصدر غير مدعوم."
    except Exception as e:
        res["error"] = "%s: %s" % (type(e).__name__, e)
        buf.write(traceback.format_exc())
    res["log"] = buf.getvalue()
    return json.dumps(res, ensure_ascii=False)


if __name__ == "__main__":
    if len(sys.argv) < 5:
        print("الاستعمال: python bridge.py <reading|language|expression> <model.docx> <source.docx> <out_dir> [api_key]")
        sys.exit(2)
    print(run(*sys.argv[1:5],
              api_key=(sys.argv[5] if len(sys.argv) > 5 else ""),
              out_name=(sys.argv[6] if len(sys.argv) > 6 else "")))
