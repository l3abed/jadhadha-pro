package com.l3abed.jadhadha.pro

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.chaquo.python.Python
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

private const val DOCX_MIME =
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document"

private data class Comp(val id: String, val label: String, val hint: String)

private val COMPS = listOf(
    Comp("reading", "القراءة", "اختر جذاذة القراءة المصدر بتخطيط «المختار 3 إع» (ملف docx)، فتُفرَّغ في القالب النموذجي «المنفى»."),
    Comp("language", "الدرس اللغوي", "اختر جذاذة الدرس اللغوي المصدر (ملف docx)، فتُفرَّغ في القالب النموذجي «اسم الفاعل وعمله»."),
    Comp("expression", "التعبير والإنشاء", "اختر جذاذة التعبير والإنشاء المصدر (ملف docx)، فتُفرَّغ في القالب النموذجي «التدرب على كتابة اليوميات»."),
)

private data class TabState(
    val sourceName: String = "",
    val sourcePath: String = "",
    val busy: Boolean = false,
    val message: String = "",
    val ok: Boolean = false,
    val outPath: String = "",
    val log: String = "",
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Surface(modifier = Modifier.fillMaxSize()) { JadhadhaApp() }
                }
            }
        }
    }
}

@Composable
private fun JadhadhaApp() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("settings", Context.MODE_PRIVATE) }

    var apiKey by remember { mutableStateOf(prefs.getString("api_key", "") ?: "") }
    var showSettings by remember { mutableStateOf(false) }
    var showLog by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    var pendingComp by remember { mutableStateOf(COMPS[0].id) }
    val states = remember { mutableStateMapOf<String, TabState>() }

    fun update(id: String, f: (TabState) -> TabState) {
        states[id] = f(states[id] ?: TabState())
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        val id = pendingComp
        if (uri != null) {
            scope.launch {
                val res = withContext(Dispatchers.IO) { runCatching { importSource(ctx, uri, id) } }
                res.onSuccess { pair ->
                    update(id) { TabState(sourceName = pair.first, sourcePath = pair.second) }
                }
                res.onFailure { e ->
                    update(id) { it.copy(ok = false, message = "تعذّر فتح الملف: ${e.message}") }
                }
            }
        }
    }

    fun runComp(id: String) {
        val st = states[id] ?: return
        if (st.sourcePath.isEmpty() || st.busy) return
        update(id) {
            it.copy(busy = true, ok = false, message = "جارٍ التفريغ… قد يستغرق ثوانيَ.", outPath = "", log = "")
        }
        scope.launch {
            val res = withContext(Dispatchers.Default) {
                runCatching { runBridge(ctx, id, st.sourcePath, st.sourceName, apiKey.trim()) }
            }
            res.onSuccess { j ->
                val ok = j.optBoolean("ok")
                update(id) {
                    it.copy(
                        busy = false,
                        ok = ok,
                        outPath = j.optString("path"),
                        message = if (ok) "تمّ إنجاز الجذاذة ✔" else "تعذّر التفريغ: " + j.optString("error"),
                        log = j.optString("log"),
                    )
                }
            }
            res.onFailure { e ->
                update(id) { it.copy(busy = false, ok = false, message = "خطأ: ${e.message}") }
            }
        }
    }

    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "الجذاذة النموذجية",
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.weight(1f),
            )
            TextButton(onClick = { showSettings = !showSettings }) {
                Text(if (showSettings) "إغلاق الإعدادات" else "الإعدادات")
            }
        }

        if (showSettings) {
            SettingsCard(apiKey) { v ->
                apiKey = v
                prefs.edit().putString("api_key", v).apply()
            }
        }

        TabRow(selectedTabIndex = tab) {
            COMPS.forEachIndexed { i, c ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(c.label) })
            }
        }

        val comp = COMPS[tab]
        val st = states[comp.id] ?: TabState()

        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(comp.hint, style = MaterialTheme.typography.bodyMedium)

            OutlinedButton(
                onClick = {
                    pendingComp = comp.id
                    picker.launch(arrayOf("*/*"))
                },
                enabled = !st.busy,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(if (st.sourceName.isEmpty()) "اختيار الجذاذة المصدر" else "المصدر: ${st.sourceName}")
            }

            Button(
                onClick = { runComp(comp.id) },
                enabled = st.sourcePath.isNotEmpty() && !st.busy,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text("تفريغ إلى القالب النموذجي")
            }

            if (st.busy) {
                LinearProgressIndicator(Modifier.fillMaxWidth())
            }

            if (st.message.isNotEmpty()) {
                Text(
                    st.message,
                    color = if (st.ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                )
            }

            if (st.ok && st.outPath.isNotEmpty()) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { openOrShare(ctx, st.outPath, view = true) },
                        modifier = Modifier.weight(1f),
                    ) { Text("فتح") }
                    OutlinedButton(
                        onClick = { openOrShare(ctx, st.outPath, view = false) },
                        modifier = Modifier.weight(1f),
                    ) { Text("مشاركة / حفظ") }
                }
            }

            if (st.log.isNotEmpty()) {
                TextButton(onClick = { showLog = !showLog }) {
                    Text(if (showLog) "إخفاء التقرير" else "عرض التقرير")
                }
                if (showLog) {
                    Text(st.log.takeLast(4000), fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun SettingsCard(apiKey: String, onChange: (String) -> Unit) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("مفتاح Gemini (اختياري)", style = MaterialTheme.typography.titleSmall)
            Text(
                "بدون مفتاح يعمل التفريغ دون إنترنت. مع المفتاح يملأ الذكاء الاصطناعي الخانات الفارغة فقط، ولا يلمس نصاً من المصدر.",
                style = MaterialTheme.typography.bodySmall,
            )
            OutlinedTextField(
                value = apiKey,
                onValueChange = onChange,
                singleLine = true,
                label = { Text("المفتاح") },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

/** ينسخ الملف المختار إلى مخزن التطبيق ويعيد (اسمه الظاهر، مساره). */
private fun importSource(ctx: Context, uri: Uri, id: String): Pair<String, String> {
    var name = "source.docx"
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (i >= 0 && c.moveToFirst()) {
            name = c.getString(i) ?: name
        }
    }
    val dir = File(ctx.filesDir, "inputs").apply { mkdirs() }
    val dest = File(dir, "$id.docx")
    val input = ctx.contentResolver.openInputStream(uri)
        ?: throw IllegalStateException("لا يمكن قراءة الملف")
    input.use { src -> dest.outputStream().use { out -> src.copyTo(out) } }
    return Pair(name, dest.absolutePath)
}

/** ينسخ القالب المضمَّن من assets إلى مخزن التطبيق (Python يحتاج مساراً حقيقياً). */
private fun ensureModel(ctx: Context, comp: String): File {
    val dir = File(ctx.filesDir, "models").apply { mkdirs() }
    val dest = File(dir, "$comp.docx")
    ctx.assets.open("models/$comp.docx").use { src ->
        dest.outputStream().use { out -> src.copyTo(out) }
    }
    return dest
}

private fun runBridge(
    ctx: Context,
    comp: String,
    sourcePath: String,
    displayName: String,
    apiKey: String,
): JSONObject {
    val model = ensureModel(ctx, comp)
    val outDir = File(ctx.filesDir, "out/$comp").apply { mkdirs() }
    val outName = "جذاذة_" + displayName.substringBeforeLast('.') + ".docx"
    val py = Python.getInstance()
    val json = py.getModule("bridge")
        .callAttr("run", comp, model.absolutePath, sourcePath, outDir.absolutePath, apiKey, outName)
        .toString()
    return JSONObject(json)
}

private fun openOrShare(ctx: Context, path: String, view: Boolean) {
    try {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", File(path))
        val intent = if (view) {
            Intent(Intent.ACTION_VIEW).setDataAndType(uri, DOCX_MIME)
        } else {
            Intent(Intent.ACTION_SEND).setType(DOCX_MIME).putExtra(Intent.EXTRA_STREAM, uri)
        }
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(if (view) intent else Intent.createChooser(intent, "مشاركة الجذاذة"))
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(ctx, "لا يوجد تطبيق يفتح ملفات Word. جرّب «مشاركة / حفظ».", Toast.LENGTH_LONG).show()
    } catch (e: Exception) {
        Toast.makeText(ctx, "تعذّر: ${e.message}", Toast.LENGTH_LONG).show()
    }
}
