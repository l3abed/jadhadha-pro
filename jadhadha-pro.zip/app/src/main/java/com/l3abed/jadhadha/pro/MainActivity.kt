package com.l3abed.jadhadha.pro

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import com.chaquo.python.Python
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

private const val APP_VERSION = "2.6.0"
private const val DOCX_MIME =
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document"

private const val ROOT_NAME = "جذاذات الثالثة إعدادي"
private val COMP_FOLDERS = listOf("القراءة", "الدرس اللغوي", "التعبير والإنشاء")
private val UNIT_FOLDERS = listOf("الأولى", "الثانية", "الثالثة", "الرابعة", "الخامسة", "السادسة")
    .map { "الوحدة $it" }

// ───── الهوية البصرية: ورق دافئ، أخضر زمردي، ذهب ─────
private val Emerald = Color(0xFF1B5E20)
private val EmeraldDark = Color(0xFF0C3512)
private val EmeraldSoft = Color(0xFFE4EFE2)
private val Gold = Color(0xFFB8860B)
private val Paper = Color(0xFFFAF7F0)
private val Ink = Color(0xFF1E2A22)
private val Muted = Color(0xFF5E6A62)
private val Line = Color(0xFFDDD7C6)
private val ErrorRed = Color(0xFFB3261E)
private val ErrorSoft = Color(0xFFFBE9E7)

private data class Comp(val id: String, val label: String)

private val COMPS = listOf(
    Comp("reading", "القراءة"),
    Comp("language", "الدرس اللغوي"),
    Comp("expression", "التعبير والإنشاء"),
)

private data class TabState(
    val sourceName: String = "",
    val sourcePath: String = "",
    val busy: Boolean = false,
    val message: String = "",
    val ok: Boolean = false,
    val outPath: String = "",
    val log: String = "",
    val folderComp: String = "",
    val folderUnit: String = "",
    val saveMsg: String = "",
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT))
        setContent {
            JadhadhaTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Surface(modifier = Modifier.fillMaxSize(), color = Paper) { JadhadhaApp() }
                }
            }
        }
    }
}

@Composable
private fun JadhadhaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Emerald,
            onPrimary = Color.White,
            secondary = Gold,
            onSecondary = Color.White,
            background = Paper,
            onBackground = Ink,
            surface = Color.White,
            onSurface = Ink,
            error = ErrorRed,
        ),
        content = content,
    )
}

@Composable
private fun JadhadhaApp() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("settings", Context.MODE_PRIVATE) }

    var apiKey by remember { mutableStateOf(prefs.getString("api_key", "") ?: "") }
    var hTeacher by remember { mutableStateOf(prefs.getString("h_teacher", "") ?: "") }
    var hSchool by remember { mutableStateOf(prefs.getString("h_school", "") ?: "") }
    var hLevel by remember { mutableStateOf(prefs.getString("h_level", "") ?: "") }
    var styleKey by remember { mutableStateOf(prefs.getString("style", "classic") ?: "classic") }
    var showSettings by remember { mutableStateOf(false) }
    var showLog by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    var pendingComp by remember { mutableStateOf(COMPS[0].id) }
    val states = remember { mutableStateMapOf<String, TabState>() }
    var treeUri by remember { mutableStateOf(prefs.getString("tree_uri", null)) }
    var storageMsg by remember { mutableStateOf("") }

    fun update(id: String, f: (TabState) -> TabState) {
        states[id] = f(states[id] ?: TabState())
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        val id = pendingComp
        if (uri != null) {
            scope.launch {
                val res = withContext(Dispatchers.IO) { runCatching { importSource(ctx, uri, id) } }
                res.onSuccess { pair ->
                    update(id) { TabState(sourceName = pair.first, sourcePath = pair.second) }
                }
                res.onFailure { e ->
                    update(id) { it.copy(ok = false, message = "تعذّر فتح الملف: ${e.message}") }
                }
            }
        }
    }

    val treePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
                )
            } catch (e: Exception) {
                // نتابع حتى إن لم يمكن حفظ الإذن بشكل دائم
            }
            prefs.edit().putString("tree_uri", uri.toString()).apply()
            treeUri = uri.toString()
            storageMsg = "جارٍ إنشاء المجلدات…"
            scope.launch {
                val res = withContext(Dispatchers.IO) { runCatching { ensureTree(ctx, uri) } }
                storageMsg = if (res.isSuccess) {
                    "تمّ إنشاء «$ROOT_NAME» بثلاثة مجلدات للمكوّنات، وفي كل منها ستة مجلدات للوحدات ✔"
                } else {
                    "تعذّر إنشاء المجلدات: ${res.exceptionOrNull()?.message}"
                }
            }
        }
    }

    fun chooseUnit(id: String, unit: String) {
        val st = states[id] ?: return
        scope.launch {
            withContext(Dispatchers.IO) {
                runCatching {
                    Python.getInstance().getModule("bridge")
                        .callAttr("apply_header_json", st.outPath, JSONObject().put("unit", unit).toString())
                }
            }
            update(id) { it.copy(folderUnit = "الوحدة $unit") }
        }
    }

    fun saveComp(id: String) {
        val st = states[id] ?: return
        val uriStr = treeUri
        if (uriStr == null) {
            update(id) { it.copy(saveMsg = "اختر أولاً مكان التخزين من «الإعدادات».") }
            showSettings = true
            return
        }
        scope.launch {
            val res = withContext(Dispatchers.IO) {
                runCatching { storeDocx(ctx, Uri.parse(uriStr), st.outPath, st.folderComp, st.folderUnit) }
            }
            if (res.isSuccess) {
                update(id) { it.copy(saveMsg = "خُزّنت في: ${res.getOrNull()} ✔") }
            } else {
                update(id) { it.copy(saveMsg = "تعذّر التخزين: ${res.exceptionOrNull()?.message}") }
            }
        }
    }

    fun runComp(id: String) {
        val st = states[id] ?: return
        if (st.sourcePath.isEmpty() || st.busy) return
        update(id) {
            it.copy(busy = true, ok = false, message = "جارٍ التفريغ… قد يستغرق ثوانيَ.", outPath = "", log = "", saveMsg = "")
        }
        scope.launch {
            val res = withContext(Dispatchers.Default) {
                runCatching { runBridge(ctx, id, st.sourcePath, st.sourceName, apiKey.trim(), headerJson(hTeacher, hSchool, hLevel), styleKey) }
            }
            res.onSuccess { j ->
                val ok = j.optBoolean("ok")
                update(id) {
                    it.copy(
                        busy = false,
                        ok = ok,
                        outPath = j.optString("path"),
                        message = if (ok) "تمّ إنجاز الجذاذة ✔" else "تعذّر التفريغ: " + j.optString("error"),
                        log = j.optString("log"),
                        folderComp = j.optJSONObject("target")?.optString("component") ?: "",
                        folderUnit = j.optJSONObject("target")?.optString("unit") ?: "",
                    )
                }
            }
            res.onFailure { e ->
                update(id) { it.copy(busy = false, ok = false, message = "خطأ: ${e.message}") }
            }
        }
    }

    val comp = COMPS[tab]
    val st = states[comp.id] ?: TabState()

    Column(Modifier.fillMaxSize()) {
        Hero(showSettings) { showSettings = !showSettings }

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .imePadding()
                .padding(horizontal = 16.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            if (showSettings) {
                HeaderCard(hTeacher, hSchool, hLevel) { t, sc, lv ->
                hTeacher = t
                hSchool = sc
                hLevel = lv
                prefs.edit().putString("h_teacher", t).putString("h_school", sc).putString("h_level", lv).apply()
            }
            StorageCard(treeUri, storageMsg) { treePicker.launch(null) }
                SettingsCard(apiKey) { v ->
                    apiKey = v
                    prefs.edit().putString("api_key", v).apply()
                }
            }

            ComponentSelector(tab) { tab = it }

            SoftCard {
                StepTitle("١", "اختر الجذاذة المصدر")
                OutlinedButton(
                    onClick = {
                        pendingComp = comp.id
                        picker.launch(arrayOf("*/*"))
                    },
                    enabled = !st.busy,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.5.dp, Emerald),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Emerald),
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                ) {
                    Text(
                        if (st.sourceName.isEmpty()) "اختيار ملف docx" else "✔  " + st.sourceName,
                        maxLines = 1,
                        fontWeight = FontWeight.Medium,
                    )
                }

                StepTitle("٢", "اختر النمط")
                StylePicker(styleKey) { k ->
                    styleKey = k
                    prefs.edit().putString("style", k).apply()
                }
                StepTitle("٣", "فرّغها في القالب النموذجي")
                SolidButton(
                    text = "تفريغ الجذاذة",
                    color = Emerald,
                    enabled = st.sourcePath.isNotEmpty() && !st.busy,
                    onClick = { runComp(comp.id) },
                    modifier = Modifier.fillMaxWidth(),
                )

                if (st.busy) {
                    LinearProgressIndicator(
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(50)),
                        color = Emerald,
                        trackColor = EmeraldSoft,
                    )
                }
                if (st.message.isNotEmpty()) {
                    StatusBox(st.message, if (st.busy) 0 else if (st.ok) 1 else 2)
                }
            }

            if (st.ok && st.outPath.isNotEmpty()) {
                SoftCard {
                    StepTitle("٤", "افتح الجذاذة أو خزّنها")
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SolidButton(
                            text = "فتح",
                            color = Emerald,
                            onClick = { openOrShare(ctx, st.outPath, view = true) },
                            modifier = Modifier.weight(1f),
                        )
                        OutlinedButton(
                            onClick = { openOrShare(ctx, st.outPath, view = false) },
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.5.dp, Emerald),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Emerald),
                            modifier = Modifier.weight(1f).height(52.dp),
                        ) { Text("مشاركة / حفظ", fontWeight = FontWeight.Bold) }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        InfoChip("المكوّن: " + st.folderComp.ifEmpty { "—" })
                        InfoChip("الوحدة: " + st.folderUnit.ifEmpty { "—" })
                    }
                    if (st.folderUnit.isEmpty()) {
                        Text("لم أجد الوحدة في الترويسة، اختر الوحدة:", fontSize = 13.sp, color = Muted)
                        UnitPicker { unit -> chooseUnit(comp.id, unit) }
                    }
                    SolidButton(
                        text = "تخزين في «$ROOT_NAME»",
                        color = Gold,
                        onClick = { saveComp(comp.id) },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    if (st.saveMsg.isNotEmpty()) {
                        StatusBox(st.saveMsg, if (st.saveMsg.contains("✔")) 1 else 2)
                    }
                }
            }

            if (st.log.isNotEmpty()) {
                TextButton(onClick = { showLog = !showLog }) {
                    Text(if (showLog) "إخفاء التقرير" else "عرض التقرير", color = Muted)
                }
                if (showLog) {
                    Text(st.log.takeLast(4000), fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Muted)
                }
            }

            Text(
                "الجذاذة النموذجية  ·  الإصدار $APP_VERSION",
                fontSize = 11.sp,
                color = Muted,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 12.dp),
            )
        }
    }
}

@Composable
private fun Hero(settingsOpen: Boolean, onSettings: () -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(bottomStart = 30.dp, bottomEnd = 30.dp))
            .background(Brush.verticalGradient(listOf(Emerald, EmeraldDark)))
            .statusBarsPadding()
            .padding(horizontal = 20.dp, vertical = 20.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    "الجذاذة النموذجية",
                    color = Color.White,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold,
                    fontSize = 28.sp,
                )
                Spacer(Modifier.height(6.dp))
                Box(Modifier.width(44.dp).height(3.dp).clip(RoundedCornerShape(2.dp)).background(Gold))
                Spacer(Modifier.height(8.dp))
                Text(
                    "من المصدر إلى القالب النموذجي بلمسة واحدة",
                    color = Color(0xCCFFFFFF),
                    fontSize = 13.sp,
                )
            }
            Box(
                Modifier
                    .clip(RoundedCornerShape(50))
                    .border(1.dp, Color(0x80FFFFFF), RoundedCornerShape(50))
                    .clickable { onSettings() }
                    .padding(horizontal = 14.dp, vertical = 8.dp),
            ) {
                Text(if (settingsOpen) "إغلاق" else "الإعدادات", color = Color.White, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun ComponentSelector(selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        COMPS.forEachIndexed { i, c ->
            val on = i == selected
            Box(
                Modifier
                    .weight(1f)
                    .height(48.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (on) Emerald else Color.White)
                    .border(1.dp, if (on) Emerald else Line, RoundedCornerShape(14.dp))
                    .clickable { onSelect(i) },
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    c.label,
                    color = if (on) Color.White else Ink,
                    fontWeight = if (on) FontWeight.Bold else FontWeight.Medium,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                )
            }
        }
    }
}

@Composable
private fun SoftCard(content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            content()
        }
    }
}

private val STYLE_CHOICES = listOf(
    "classic" to "الأصلي",
    "emerald" to "زمردي ملوّن",
    "modern" to "عصري",
    "print_bw" to "أبيض وأسود",
)

@Composable
private fun StylePicker(selected: String, onPick: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        STYLE_CHOICES.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { (key, label) ->
                    val on = key == selected
                    Box(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (on) Emerald else Color.White)
                            .border(1.dp, if (on) Emerald else Line, RoundedCornerShape(12.dp))
                            .clickable { onPick(key) }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(label, color = if (on) Color.White else Ink, fontSize = 13.sp,
                            fontWeight = if (on) FontWeight.Bold else FontWeight.Medium)
                    }
                }
            }
        }
    }
}

@Composable
private fun StepTitle(num: String, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(
            Modifier.size(28.dp).clip(CircleShape).background(EmeraldSoft),
            contentAlignment = Alignment.Center,
        ) { Text(num, color = Emerald, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
        Text(text, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Ink)
    }
}

@Composable
private fun SolidButton(
    text: String,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = color,
            contentColor = Color.White,
            disabledContainerColor = Color(0xFFCCD3CD),
            disabledContentColor = Color.White,
        ),
        modifier = modifier.height(52.dp),
    ) { Text(text, fontWeight = FontWeight.Bold, fontSize = 15.sp) }
}

@Composable
private fun StatusBox(text: String, kind: Int) {
    val bg = when (kind) { 1 -> EmeraldSoft; 2 -> ErrorSoft; else -> Paper }
    val fg = when (kind) { 1 -> Emerald; 2 -> ErrorRed; else -> Muted }
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(bg).padding(12.dp)) {
        Text(text, color = fg, fontSize = 14.sp, lineHeight = 21.sp)
    }
}

@Composable
private fun InfoChip(text: String) {
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(EmeraldSoft)
            .padding(horizontal = 12.dp, vertical = 6.dp),
    ) { Text(text, color = Emerald, fontSize = 12.sp, fontWeight = FontWeight.Medium) }
}

@Composable
private fun HeaderCard(teacher: String, school: String, level: String, onChange: (String, String, String) -> Unit) {
    SoftCard {
        Text("بيانات الترويسة", fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text(
            "تُكتب هذه القيم في ترويسة كل جذاذة ناتجة. اترك الخانة فارغة لاعتماد ما في القالب أو الجذاذة.",
            fontSize = 13.sp,
            color = Muted,
            lineHeight = 20.sp,
        )
        OutlinedTextField(
            value = teacher,
            onValueChange = { onChange(it, school, level) },
            singleLine = true,
            label = { Text("الأستاذ(ة)") },
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = school,
            onValueChange = { onChange(teacher, it, level) },
            singleLine = true,
            label = { Text("المؤسسة") },
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = level,
            onValueChange = { onChange(teacher, school, it) },
            singleLine = true,
            label = { Text("الفئة المستهدفة (مثال: السنة الثالثة إعدادي)") },
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

@Composable
private fun UnitPicker(onPick: (String) -> Unit) {
    val names = listOf("الأولى", "الثانية", "الثالثة", "الرابعة", "الخامسة", "السادسة")
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        names.chunked(3).forEach { rowNames ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                rowNames.forEach { n ->
                    Box(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(50))
                            .border(1.dp, Emerald, RoundedCornerShape(50))
                            .clickable { onPick(n) }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center,
                    ) { Text(n, color = Emerald, fontSize = 13.sp, fontWeight = FontWeight.Medium) }
                }
            }
        }
    }
}

@Composable
private fun StorageCard(treeUri: String?, message: String, onPick: () -> Unit) {
    SoftCard {
        Text("مكان التخزين", fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text(
            "يُنشئ التطبيق في المكان الذي تختاره مجلد «$ROOT_NAME»، وفيه مجلدات المكوّنات الثلاثة، وفي كل منها ستة مجلدات للوحدات. اختر مثلاً «Documents» ثم «استخدام هذا المجلد».",
            fontSize = 13.sp,
            color = Muted,
            lineHeight = 20.sp,
        )
        val where = treeUri?.let { Uri.parse(it).lastPathSegment ?: it }
        InfoChip(if (where == null) "لم يُحدَّد مكان بعد" else "المكان: $where")
        if (message.isNotEmpty()) StatusBox(message, if (message.contains("✔")) 1 else 0)
        OutlinedButton(
            onClick = onPick,
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.5.dp, Emerald),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Emerald),
            modifier = Modifier.fillMaxWidth().height(52.dp),
        ) {
            Text(
                if (treeUri == null) "اختيار المكان وإنشاء المجلدات" else "تغيير المكان / إعادة إنشاء المجلدات",
                fontWeight = FontWeight.Bold,
            )
        }
    }
}

@Composable
private fun SettingsCard(apiKey: String, onChange: (String) -> Unit) {
    SoftCard {
        Text("مفتاح Gemini (اختياري)", fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text(
            "بدون مفتاح يعمل التفريغ دون إنترنت. مع المفتاح يملأ الذكاء الاصطناعي الخانات الفارغة فقط، ولا يلمس نصاً من المصدر.",
            fontSize = 13.sp,
            color = Muted,
            lineHeight = 20.sp,
        )
        OutlinedTextField(
            value = apiKey,
            onValueChange = onChange,
            singleLine = true,
            label = { Text("المفتاح") },
            visualTransformation = PasswordVisualTransformation(),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

/** ينشئ شجرة المجلدات (الجذر ← 3 مكوّنات ← 6 وحدات لكل مكوّن) إن لم تكن موجودة. */
private fun ensureTree(ctx: Context, treeUri: Uri): DocumentFile {
    val base = DocumentFile.fromTreeUri(ctx, treeUri)
        ?: throw IllegalStateException("تعذّر الوصول إلى المكان المختار")
    val root = childDir(base, ROOT_NAME)
    for (c in COMP_FOLDERS) {
        val cd = childDir(root, c)
        for (u in UNIT_FOLDERS) childDir(cd, u)
    }
    return root
}

private fun childDir(parent: DocumentFile, name: String): DocumentFile {
    val found = parent.findFile(name)
    if (found != null && found.isDirectory) return found
    return parent.createDirectory(name)
        ?: throw IllegalStateException("تعذّر إنشاء المجلد «$name»")
}

/** يخزّن الملف في «الجذر/المكوّن/الوحدة»؛ يستبدل الملف إن وُجد بالاسم نفسه. يعيد المسار الظاهر. */
private fun storeDocx(ctx: Context, treeUri: Uri, srcPath: String, comp: String, unit: String): String {
    if (comp.isBlank()) throw IllegalStateException("تعذّر تحديد المكوّن من الترويسة")
    val root = ensureTree(ctx, treeUri)
    val cd = childDir(root, comp)
    val target = if (unit.isBlank()) cd else childDir(cd, unit)
    val src = File(srcPath)
    target.findFile(src.name)?.delete()
    val f = target.createFile(DOCX_MIME, src.name)
        ?: throw IllegalStateException("تعذّر إنشاء الملف")
    val out = ctx.contentResolver.openOutputStream(f.uri)
        ?: throw IllegalStateException("تعذّر الكتابة في الملف")
    out.use { o -> src.inputStream().use { it.copyTo(o) } }
    val where = if (unit.isBlank()) "$ROOT_NAME/$comp" else "$ROOT_NAME/$comp/$unit"
    return "$where/${f.name ?: src.name}"
}

/** ينسخ الملف المختار إلى مخزن التطبيق ويعيد (اسمه الظاهر، مساره). */
private fun importSource(ctx: Context, uri: Uri, id: String): Pair<String, String> {
    var name = "source.docx"
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (i >= 0 && c.moveToFirst()) {
            name = c.getString(i) ?: name
        }
    }
    val dir = File(ctx.filesDir, "inputs").apply { mkdirs() }
    val dest = File(dir, "$id.docx")
    val input = ctx.contentResolver.openInputStream(uri)
        ?: throw IllegalStateException("لا يمكن قراءة الملف")
    input.use { src -> dest.outputStream().use { out -> src.copyTo(out) } }
    return Pair(name, dest.absolutePath)
}

/** ينسخ القالب المضمَّن من assets إلى مخزن التطبيق (Python يحتاج مساراً حقيقياً). */
private fun ensureModel(ctx: Context, comp: String): File {
    val dir = File(ctx.filesDir, "models").apply { mkdirs() }
    val dest = File(dir, "$comp.docx")
    ctx.assets.open("models/$comp.docx").use { src ->
        dest.outputStream().use { out -> src.copyTo(out) }
    }
    return dest
}

private fun headerJson(teacher: String, school: String, level: String): String =
    JSONObject().put("teacher", teacher.trim()).put("school", school.trim()).put("level", level.trim()).toString()

private fun runBridge(
    ctx: Context,
    comp: String,
    sourcePath: String,
    displayName: String,
    apiKey: String,
    headerJson: String,
    style: String,
): JSONObject {
    val model = ensureModel(ctx, comp)
    val outDir = File(ctx.filesDir, "out/$comp").apply { mkdirs() }
    val outName = "جذاذة_" + displayName.substringBeforeLast('.') + ".docx"
    val py = Python.getInstance()
    val json = py.getModule("bridge")
        .callAttr("run", comp, model.absolutePath, sourcePath, outDir.absolutePath, apiKey, outName, headerJson, style)
        .toString()
    return JSONObject(json)
}

private fun openOrShare(ctx: Context, path: String, view: Boolean) {
    try {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", File(path))
        val intent = if (view) {
            Intent(Intent.ACTION_VIEW).setDataAndType(uri, DOCX_MIME)
        } else {
            Intent(Intent.ACTION_SEND).setType(DOCX_MIME).putExtra(Intent.EXTRA_STREAM, uri)
        }
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(if (view) intent else Intent.createChooser(intent, "مشاركة الجذاذة"))
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(ctx, "لا يوجد تطبيق يفتح ملفات Word. جرّب «مشاركة / حفظ».", Toast.LENGTH_LONG).show()
    } catch (e: Exception) {
        Toast.makeText(ctx, "تعذّر: ${e.message}", Toast.LENGTH_LONG).show()
    }
}
