# الجذاذة النموذجية 2.0

تطبيق أندرويد يفرّغ الجذاذات المصدرية (docx) في القوالب النموذجية، بثلاثة مكوّنات:
القراءة، الدرس اللغوي، التعبير والإنشاء.

- يشغّل سكريبتات Python نفسها (python-docx) داخل التطبيق عبر Chaquopy، فالناتج مطابق للسكريبت.
- القوالب مضمَّنة في `app/src/main/assets/models/`.
- لا مفتاح داخل الكود؛ مفتاح Gemini اختياري ويُدخل من الإعدادات.
- شغّل `python app/src/main/python/bridge.py <reading|language|expression> model.docx source.docx out_dir` للتجربة على الحاسوب.
